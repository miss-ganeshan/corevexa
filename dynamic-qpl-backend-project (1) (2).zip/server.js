const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const auditLog = [];
const papers = new Map();

// Demo question bank. Replace this with a real DB later.
const questionBank = Array.from({ length: 100 }, (_, i) => {
  const n = i + 1;
  const difficulties = ["Easy", "Medium", "Very Hard"];
  const difficulty = difficulties[i % 3];
  return {
    id: `Q-${String(n).padStart(3, "0")}`,
    text: `${difficulty} examination question ${n}`,
    difficulty,
    previousExamFrequency: 100 - i
  };
});

function addAudit(event, actor = "System", metadata = {}) {
  auditLog.unshift({
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    event,
    actor,
    metadata
  });
}

function shuffle(items) {
  return [...items].sort(() => Math.random() - 0.5);
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function generatePaper({ bankSize, repeatCount, mediumCount, hardCount, useHistory = true }) {
  if (!Number.isInteger(bankSize) || bankSize < 25 || bankSize > questionBank.length) {
    throw new Error(`bankSize must be between 25 and ${questionBank.length}`);
  }
  if (![repeatCount, mediumCount, hardCount].every(Number.isInteger)) {
    throw new Error("Question counts must be integers.");
  }
  if (repeatCount < 0 || mediumCount < 0 || hardCount < 0) {
    throw new Error("Question counts cannot be negative.");
  }
  if (repeatCount + mediumCount + hardCount !== 25) {
    throw new Error("repeatCount + mediumCount + hardCount must equal exactly 25.");
  }

  const bank = questionBank.slice(0, bankSize);

  // Highest previous-exam frequency first.
  const repeatedPool = useHistory
    ? [...bank].sort((a, b) => b.previousExamFrequency - a.previousExamFrequency)
    : shuffle(bank);

  const repeated = repeatedPool.slice(0, repeatCount);

  const used = new Set(repeated.map(q => q.id));
  const mediumPool = shuffle(bank.filter(q => q.difficulty === "Medium" && !used.has(q.id)));
  const medium = mediumPool.slice(0, mediumCount);
  medium.forEach(q => used.add(q.id));

  const hardPool = shuffle(bank.filter(q => q.difficulty === "Very Hard" && !used.has(q.id)));
  const hard = hardPool.slice(0, hardCount);

  if (repeated.length !== repeatCount || medium.length !== mediumCount || hard.length !== hardCount) {
    throw new Error(
      "Not enough questions in the requested pools. Add more questions or change the allocation."
    );
  }

  const questions = [
    ...repeated.map(q => ({ ...q, type: "Most Repeated", cssClass: "badge-repeat" })),
    ...medium.map(q => ({ ...q, type: "Medium", cssClass: "badge-medium" })),
    ...hard.map(q => ({ ...q, type: "Very Hard", cssClass: "badge-hard" }))
  ];

  const paperId = `CRX-EXAM-${new Date().getFullYear()}-${String(papers.size + 1).padStart(3, "0")}`;
  const payload = JSON.stringify(questions.map(({ id, difficulty, previousExamFrequency }) =>
    ({ id, difficulty, previousExamFrequency })
  ));
  const integrityHash = sha256(payload);

  const paper = {
    paperId,
    totalQuestions: questions.length,
    createdAt: new Date().toISOString(),
    integrityHash,
    questions
  };

  papers.set(paperId, paper);
  addAudit("Paper Generated", "Admin", {
    paperId,
    totalQuestions: paper.totalQuestions,
    integrityHash
  });

  return paper;
}

app.get("/api/health", (req, res) => {
  res.json({ status: "online", service: "Dynamic QPL Backend", time: new Date().toISOString() });
});

app.get("/api/questions", (req, res) => {
  res.json({
    total: questionBank.length,
    questions: questionBank
  });
});

app.post("/api/papers/generate", (req, res) => {
  try {
    const paper = generatePaper(req.body);
    res.status(201).json({
      success: true,
      message: "Paper generated successfully.",
      paper
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

app.get("/api/papers/:paperId", (req, res) => {
  const paper = papers.get(req.params.paperId);
  if (!paper) return res.status(404).json({ error: "Paper not found." });
  res.json({ success: true, paper });
});

app.get("/api/papers/:paperId/verify", (req, res) => {
  const paper = papers.get(req.params.paperId);
  if (!paper) return res.status(404).json({ error: "Paper not found." });

  const payload = JSON.stringify(paper.questions.map(({ id, difficulty, previousExamFrequency }) =>
    ({ id, difficulty, previousExamFrequency })
  ));
  const currentHash = sha256(payload);
  const valid = currentHash === paper.integrityHash;

  addAudit(valid ? "Paper Verification Success" : "Paper Verification Failed", "Admin", {
    paperId: paper.paperId
  });

  if (!valid) return res.status(409).json({ error: "Integrity verification failed." });

  res.json({
    success: true,
    valid: true,
    message: `Authentic Paper — SHA-256 integrity verification passed for ${paper.paperId}.`
  });
});

app.post("/api/auth/mfa", (req, res) => {
  // Demo MFA endpoint. In production, connect this to a real identity provider/TOTP.
  addAudit("MFA Authentication", req.body?.user || "Unknown");
  res.json({
    success: true,
    authenticated: true,
    message: "MFA verified. Secure vault access granted for this session."
  });
});

app.get("/api/audit", (req, res) => {
  res.json({ success: true, total: auditLog.length, events: auditLog });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`\nDynamic QPL Backend running: http://localhost:${PORT}`);
  console.log(`Health check:               http://localhost:${PORT}/api/health`);
});
