@echo off
echo Installing dependencies...
call npm install
echo.
echo Starting Dynamic QPL...
call npm start
pause
