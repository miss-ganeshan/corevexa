# Dynamic QPL — Backend + Frontend

This is a simple Node.js/Express backend connected to the uploaded Dynamic QPL frontend.

## Requirements
- Node.js 18+ (Node.js 20+ recommended)

## Run

Open Command Prompt/PowerShell in this folder:

```bash
npm install
npm start
```

Then open:

http://localhost:5000

## Test backend

Open:

http://localhost:5000/api/health

## Main API endpoints

- `GET /api/health`
- `GET /api/questions`
- `POST /api/papers/generate`
- `GET /api/papers/:paperId`
- `GET /api/papers/:paperId/verify`
- `POST /api/auth/mfa`
- `GET /api/audit`

## Important

This is a working prototype backend. The question bank and audit data are stored in memory, so restarting the server resets them.

For a real deployment, replace the in-memory store with PostgreSQL/MySQL/MongoDB, implement real authentication/MFA, use a proper secrets manager/key management system, and add role-based authorization.
